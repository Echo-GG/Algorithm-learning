# pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <vector>

struct AdjEdge {
	int to;
	int id;
};

struct Edge {
	int u;
	int v;
};

struct Graph {
	int vertex_count = 0;
	int edge_count = 0;
	std::vector<Edge> edges;
	std::vector<std::vector<AdjEdge>> adjacency_list;
};

int readGraph(const std::string& file_address, Graph& graph);
int readGraph(const std::string& file_address);
void print(const Graph& graph);
