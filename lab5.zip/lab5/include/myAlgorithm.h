# pragma once
#include <iostream>
#include <vector>

#include "myFile.h"

std::vector<int> Baseline(const Graph& graph);
std::vector<int> AdvancedUnionFind(const Graph& graph);
