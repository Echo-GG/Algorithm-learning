#include <iostream>
#include <vector>
#include <ctime>
#include <iomanip>
#include "myAlgorithm.h"
#include "myFile.h"
using namespace std;

static double elapsedMs(clock_t begin, clock_t end) {
    return 1000.0 * static_cast<double>(end - begin) / CLOCKS_PER_SEC;
}

static void printBridges(const Graph& graph, const std::vector<int>& bridgeEdgeIds) {
    cout << "bridge_count: " << bridgeEdgeIds.size() << "\n";
    for (size_t i = 0; i < bridgeEdgeIds.size(); ++i) {
        int id = bridgeEdgeIds[i];
        const Edge& e = graph.edges[static_cast<size_t>(id)];
        cout << e.u << ' ' << e.v << "\n";
    }
}

int main()
{
    int fileReadStatus = -1;
    string file_address;
    cout << "Please input the address of the target file." << endl;
    cin >> file_address;
    Graph graph;
    fileReadStatus = readGraph(file_address, graph);
    if (fileReadStatus == 1) {
        cout << "Graph loaded.\n";
        cout << "V=" << graph.vertex_count << ", E=" << graph.edge_count << "\n";

        const int BASELINE_MAX_EDGES = 5000;
        if (graph.edge_count <= BASELINE_MAX_EDGES) {
            clock_t t1 = clock();
            std::vector<int> bridges1 = Baseline(graph);
            clock_t t2 = clock();
            double ms1 = elapsedMs(t1, t2);
            cout << "\n[Baseline] time=" << fixed << setprecision(3) << ms1 << " ms\n";
            printBridges(graph, bridges1);
        } else {
            cout << "\n[Baseline] skipped (E too large).\n";
        }

        clock_t t3 = clock();
        std::vector<int> bridges2 = AdvancedUnionFind(graph);
        clock_t t4 = clock();
        double ms2 = elapsedMs(t3, t4);
        cout << "\n[UnionFind] time=" << fixed << setprecision(3) << ms2 << " ms\n";
        printBridges(graph, bridges2);

    } else {
        cout << "Read graph failed.\n";
    }

    return 0;
}
