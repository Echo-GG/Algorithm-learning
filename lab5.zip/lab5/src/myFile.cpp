#include "myFile.h"

int readGraph(const std::string& file_address, Graph& graph) {
    std::ifstream file(file_address);
    if (!file) {
        std::cerr << "Can't open the file!" << std::endl;
        return 0;
    }

    int vertexCount = 0;
    int edgeCount = 0;
    if (!(file >> vertexCount)) {
        std::cerr << "Invalid file format: missing vertex count." << std::endl;
        return 0;
    }
    if (!(file >> edgeCount)) {
        std::cerr << "Invalid file format: missing edge count." << std::endl;
        return 0;
    }
    if (vertexCount < 0 || edgeCount < 0) {
        std::cerr << "Invalid file format: negative counts." << std::endl;
        return 0;
    }

    graph.vertex_count = vertexCount;
    graph.edge_count = edgeCount;
    graph.edges.clear();
    graph.edges.reserve(static_cast<size_t>(edgeCount));
    graph.adjacency_list.assign(static_cast<size_t>(vertexCount), std::vector<AdjEdge>());

    for (int i = 0; i < edgeCount; ++i) {
        int u = 0;
        int v = 0;
        if (!(file >> u >> v)) {
            std::cerr << "Invalid file format: edge list ended early at edge " << i << "." << std::endl;
            return 0;
        }
        if (u < 0 || u >= vertexCount || v < 0 || v >= vertexCount) {
            std::cerr << "Invalid edge endpoint: (" << u << ", " << v << ") out of range." << std::endl;
            return 0;
        }

        const int edgeId = static_cast<int>(graph.edges.size());
        graph.edges.push_back(Edge{u, v});
        graph.adjacency_list[static_cast<size_t>(u)].push_back(AdjEdge{v, edgeId});
        if (u != v) {
            graph.adjacency_list[static_cast<size_t>(v)].push_back(AdjEdge{u, edgeId});
        }
    }

    return 1;
}

int readGraph(const std::string& file_address) {
    Graph graph;
    return readGraph(file_address, graph);
}

void print(const Graph& graph){

    std::cout << "vertex_count: " << graph.vertex_count << "\n";
    std::cout << "edge_count: " << graph.edge_count << "\n";

    int printVertexCount = graph.vertex_count;
    if (printVertexCount > static_cast<int>(graph.adjacency_list.size())) {
        printVertexCount = static_cast<int>(graph.adjacency_list.size());
    }

    for (int u = 0; u < printVertexCount; ++u) {
        std::cout << u << ":";
        const auto& neighbors = graph.adjacency_list[static_cast<size_t>(u)];
        for (const auto& e : neighbors) {
            std::cout << ' ' << e.to;
        }
        std::cout << "\n";
    }
}
