#include "myAlgorithm.h"

#include <algorithm>
#include <stack>

std::vector<int> Baseline(const Graph& graph) {
	std::vector<int> bridges;
	const int n = graph.vertex_count;
	const int m = static_cast<int>(graph.edges.size());
	bridges.reserve(static_cast<size_t>(m));

	std::vector<int> seen(static_cast<size_t>(n), 0);
	int token = 1;
	std::stack<int> st;

	for (int edgeId = 0; edgeId < m; ++edgeId) {
		const Edge& e = graph.edges[static_cast<size_t>(edgeId)];
		const int start = e.u;
		const int target = e.v;
		if (start == target) {
			continue;
		}

		++token;
		if (token == 0) {
			std::fill(seen.begin(), seen.end(), 0);
			token = 1;
		}

		while (!st.empty()) {
			st.pop();
		}
		seen[static_cast<size_t>(start)] = token;
		st.push(start);

		bool reachable = false;
		while (!st.empty() && !reachable) {
			int u = st.top();
			st.pop();
			const std::vector<AdjEdge>& adj = graph.adjacency_list[static_cast<size_t>(u)];
			for (size_t i = 0; i < adj.size(); ++i) {
				const AdjEdge& ae = adj[i];
				if (ae.id == edgeId) {
					continue;
				}
				const int v = ae.to;
				if (seen[static_cast<size_t>(v)] != token) {
					if (v == target) {
						reachable = true;
						break;
					}
					seen[static_cast<size_t>(v)] = token;
					st.push(v);
				}
			}
		}

		if (!reachable) {
			bridges.push_back(edgeId);
		}
	}
	return bridges;
}

struct UpDSU {
	std::vector<int> up;

	explicit UpDSU(int n) : up(static_cast<size_t>(n)) {
		for (int i = 0; i < n; ++i) {
			up[static_cast<size_t>(i)] = i;
		}
	}

	int find(int x) {
		int& p = up[static_cast<size_t>(x)];
		if (p == x) {
			return x;
		}
		p = find(p);
		return p;
	}

	void linkTo(int x, int parent) {
		up[static_cast<size_t>(x)] = find(parent);
	}
};

std::vector<int> AdvancedUnionFind(const Graph& graph) {
	const int n = graph.vertex_count;
	const int m = static_cast<int>(graph.edges.size());

	std::vector<int> parent(static_cast<size_t>(n), -1);
	std::vector<int> parentEdge(static_cast<size_t>(n), -1);
	std::vector<int> depth(static_cast<size_t>(n), 0);
	std::vector<char> visited(static_cast<size_t>(n), 0);
	std::vector<char> isTreeEdge(static_cast<size_t>(m), 0);
	std::vector<char> nonBridge(static_cast<size_t>(m), 0);

	std::vector<std::pair<int, int>> backEdges;
	backEdges.reserve(static_cast<size_t>(m));

	std::vector<size_t> iter(static_cast<size_t>(n), 0);
	std::stack<int> st;

	for (int root = 0; root < n; ++root) {
		if (visited[static_cast<size_t>(root)]) {
			continue;
		}
		visited[static_cast<size_t>(root)] = 1;
		parent[static_cast<size_t>(root)] = -1;
		parentEdge[static_cast<size_t>(root)] = -1;
		depth[static_cast<size_t>(root)] = 0;
		iter[static_cast<size_t>(root)] = 0;
		st.push(root);

		while (!st.empty()) {
			int u = st.top();
			const std::vector<AdjEdge>& adj = graph.adjacency_list[static_cast<size_t>(u)];
			size_t& idx = iter[static_cast<size_t>(u)];
			if (idx >= adj.size()) {
				st.pop();
				continue;
			}

			const AdjEdge& e = adj[idx++];
			int v = e.to;
			int edgeId = e.id;

			if (!visited[static_cast<size_t>(v)]) {
				visited[static_cast<size_t>(v)] = 1;
				parent[static_cast<size_t>(v)] = u;
				parentEdge[static_cast<size_t>(v)] = edgeId;
				depth[static_cast<size_t>(v)] = depth[static_cast<size_t>(u)] + 1;
				isTreeEdge[static_cast<size_t>(edgeId)] = 1;
				iter[static_cast<size_t>(v)] = 0;
				st.push(v);
			} else if (edgeId != parentEdge[static_cast<size_t>(u)] && depth[static_cast<size_t>(v)] < depth[static_cast<size_t>(u)]) {
				backEdges.push_back(std::make_pair(u, v));
			}
		}
	}

	UpDSU dsu(n);
	for (size_t i = 0; i < backEdges.size(); ++i) {
		int u = backEdges[i].first;
		int v = backEdges[i].second;
		int ru = dsu.find(u);
		int rv = dsu.find(v);

		while (ru != rv) {
			if (depth[static_cast<size_t>(ru)] < depth[static_cast<size_t>(rv)]) {
				std::swap(ru, rv);
			}
			int pe = parentEdge[static_cast<size_t>(ru)];
			if (pe == -1) {
				break;
			}
			nonBridge[static_cast<size_t>(pe)] = 1;
			int p = parent[static_cast<size_t>(ru)];
			if (p == -1) {
				break;
			}
			dsu.linkTo(ru, p);
			ru = dsu.find(ru);
			rv = dsu.find(rv);
		}
	}

	std::vector<int> bridges;
	for (int edgeId = 0; edgeId < m; ++edgeId) {
		if (!isTreeEdge[static_cast<size_t>(edgeId)]) {
			continue;
		}
		if (!nonBridge[static_cast<size_t>(edgeId)]) {
			bridges.push_back(edgeId);
		}
	}
	return bridges;
}
